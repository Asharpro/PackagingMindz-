import unittest
import urllib.request
import urllib.parse
import json
import sqlite3
import os
import threading
import time
from server import run_server, PORT, DB_PATH

class TestPackagingMindzSystem(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Start server in a background daemon thread
        cls.server_thread = threading.Thread(target=run_server, daemon=True)
        cls.server_thread.start()
        time.sleep(1) # Give server a moment to bind

    def test_01_database_tables(self):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in c.fetchall()]
        conn.close()
        self.assertIn("quotes", tables)
        self.assertIn("categories", tables)
        self.assertIn("products", tables)

    def test_02_seeded_counts(self):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM products")
        p_count = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM categories")
        c_count = c.fetchone()[0]
        conn.close()
        self.assertGreaterEqual(p_count, 68)
        self.assertEqual(c_count, 8)

    def test_03_http_pages(self):
        endpoints = [
            ("/", "Custom Packaging Manufacturer"),
            ("/about-us", "About Us"),
            ("/shop", "Shop"),
            ("/contact-us", "Contact Us"),
            ("/admin", "Dashboard"),
            ("/category", "Categories")
        ]
        for path, expected_text in endpoints:
            url = f"http://127.0.0.1:{PORT}{path}"
            with urllib.request.urlopen(url, timeout=5) as res:
                self.assertEqual(res.status, 200)
                html = res.read().decode('utf-8', errors='ignore')
                self.assertIn(expected_text, html, f"Failed for path {path}")

    def test_04_api_products_and_categories(self):
        url = f"http://127.0.0.1:{PORT}/api/products"
        with urllib.request.urlopen(url, timeout=5) as res:
            self.assertEqual(res.status, 200)
            data = json.loads(res.read().decode('utf-8'))
            self.assertTrue(data["success"])
            self.assertGreaterEqual(data["count"], 68)

        url_cat = f"http://127.0.0.1:{PORT}/api/categories"
        with urllib.request.urlopen(url_cat, timeout=5) as res:
            self.assertEqual(res.status, 200)
            data_cat = json.loads(res.read().decode('utf-8'))
            self.assertTrue(data_cat["success"])
            self.assertEqual(len(data_cat["categories"]), 8)

    def test_05_form_submission_and_sqlite_persistence(self):
        quote_payload = {
            "box_name": "Luxury Perfume Rigid Box",
            "length": 6.5,
            "width": 4.0,
            "depth": 2.5,
            "client_name": "Test Brand Owner",
            "address": "Los Angeles, CA 90001",
            "email": "testowner@example.com",
            "phone": "(626) 555-0199",
            "message": "We require 1,000 units with matte finish and gold hot foil stamping.",
            "page_source": "Automated Unit Test"
        }

        url = f"http://127.0.0.1:{PORT}/api/quote"
        req = urllib.request.Request(
            url,
            data=json.dumps(quote_payload).encode('utf-8'),
            headers={"Content-Type": "application/json"}
        )

        with urllib.request.urlopen(req, timeout=5) as res:
            self.assertEqual(res.status, 201)
            res_data = json.loads(res.read().decode('utf-8'))
            self.assertTrue(res_data["success"])
            quote_id = res_data["quote_id"]

        # Verify record exists in SQLite
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT box_name, client_name, email, phone, length, width, depth, status FROM quotes WHERE id = ?", (quote_id,))
        row = c.fetchone()
        conn.close()

        self.assertIsNotNone(row)
        self.assertEqual(row[0], "Luxury Perfume Rigid Box")
        self.assertEqual(row[1], "Test Brand Owner")
        self.assertEqual(row[2], "testowner@example.com")
        self.assertEqual(row[3], "(626) 555-0199")
        self.assertEqual(row[4], 6.5)
        self.assertEqual(row[5], 4.0)
        self.assertEqual(row[6], 2.5)
        self.assertEqual(row[7], "new")

    def test_06_admin_status_update_and_export(self):
        # Fetch quotes
        url_get = f"http://127.0.0.1:{PORT}/api/quotes"
        with urllib.request.urlopen(url_get, timeout=5) as res:
            self.assertEqual(res.status, 200)
            data = json.loads(res.read().decode('utf-8'))
            self.assertTrue(data["success"])
            self.assertGreaterEqual(len(data["quotes"]), 1)
            target_id = data["quotes"][0]["id"]

        # Update status
        url_update = f"http://127.0.0.1:{PORT}/api/quotes/{target_id}/status"
        req_update = urllib.request.Request(
            url_update,
            data=json.dumps({"status": "in_progress"}).encode('utf-8'),
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req_update, timeout=5) as res:
            self.assertEqual(res.status, 200)

        # Verify CSV export
        url_export = f"http://127.0.0.1:{PORT}/api/quotes/export"
        with urllib.request.urlopen(url_export, timeout=5) as res:
            self.assertEqual(res.status, 200)
            csv_content = res.read().decode('utf-8')
            self.assertIn("Luxury Perfume Rigid Box", csv_content)
            self.assertIn("testowner@example.com", csv_content)

if __name__ == "__main__":
    unittest.main()
