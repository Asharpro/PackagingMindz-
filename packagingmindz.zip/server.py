import http.server
import socketserver
import os
import json
import sqlite3
import urllib.parse
import mimetypes
import uuid
import csv
import io
from datetime import datetime
from email.parser import BytesParser
from email.policy import default

PORT = 8000
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
DB_PATH = os.path.join(BASE_DIR, "database.sqlite")

os.makedirs(UPLOADS_DIR, exist_ok=True)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

class PackagingMindzHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        super().end_headers()

    def send_json(self, data, status_code=200):
        response = json.dumps(data).encode('utf-8')
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    def send_error_json(self, message, status_code=400):
        self.send_json({"success": False, "error": message}, status_code=status_code)

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        if not self.path or self.path.strip() == "":
            self.path = "/"
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path.rstrip('/')
        if not path:
            path = '/'
        query = urllib.parse.parse_qs(parsed_url.query)

        # API Endpoints
        if path == "/api/products":
            self.handle_get_products(query)
            return
        elif path.startswith("/api/products/"):
            slug = path[len("/api/products/"):].strip('/')
            self.handle_get_product_by_slug(slug)
            return
        elif path == "/api/categories":
            self.handle_get_categories()
            return
        elif path == "/api/quotes":
            self.handle_get_quotes(query)
            return
        elif path == "/api/quotes/export":
            self.handle_export_quotes()
            return

        # Uploaded files serving
        if parsed_url.path.startswith("/uploads/"):
            file_name = parsed_url.path[len("/uploads/"):].strip('/')
            file_path = os.path.join(UPLOADS_DIR, file_name)
            if os.path.exists(file_path) and os.path.isfile(file_path):
                mime, _ = mimetypes.guess_type(file_path)
                with open(file_path, "rb") as f:
                    content = f.read()
                self.send_response(200)
                self.send_header("Content-Type", mime or "application/octet-stream")
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            else:
                self.send_error(404, "File Not Found")
                return

        # Clean URL Rewrites
        url_map = {
            '/': 'index.html',
            '/about-us': 'about-us.html',
            '/contact-us': 'contact-us.html',
            '/shop': 'shop.html',
            '/category': 'category.html',
            '/blog': 'blog.html',
            '/privacy-policy': 'privacy-policy.html',
            '/terms-and-conditions': 'terms-and-conditions.html',
            '/admin': 'admin.html',
        }

        if path in url_map:
            target_file = os.path.join(BASE_DIR, url_map[path])
            if os.path.exists(target_file):
                self.path = '/' + url_map[path]
                return super().do_GET()

        # Dynamic routes
        if path.startswith("/product/"):
            self.path = '/product.html'
            return super().do_GET()

        if path.startswith("/product-category/"):
            self.path = '/category.html'
            return super().do_GET()

        return super().do_GET()

    def do_POST(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path.rstrip('/')

        if path == "/api/quote" or path == "/api/quotes":
            self.handle_post_quote()
            return
        elif path.startswith("/api/quotes/") and path.endswith("/status"):
            parts = path.split('/')
            quote_id = parts[3]
            self.handle_update_quote_status(quote_id)
            return

        self.send_error(404, "Endpoint Not Found")

    def do_PATCH(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path.rstrip('/')
        if path.startswith("/api/quotes/"):
            quote_id = path[len("/api/quotes/"):].strip('/')
            self.handle_update_quote_status(quote_id)
            return
        self.send_error(404, "Endpoint Not Found")

    def do_DELETE(self):
        parsed_url = urllib.parse.urlparse(self.path)
        path = parsed_url.path.rstrip('/')
        if path.startswith("/api/quotes/"):
            quote_id = path[len("/api/quotes/"):].strip('/')
            self.handle_delete_quote(quote_id)
            return
        self.send_error(404, "Endpoint Not Found")

    def handle_get_products(self, query):
        conn = get_db()
        cursor = conn.cursor()
        sql = "SELECT * FROM products WHERE 1=1"
        count_sql = "SELECT COUNT(*) FROM products WHERE 1=1"
        params = []

        cat = query.get('category', [None])[0]
        if cat:
            sql += " AND category_slug = ?"
            count_sql += " AND category_slug = ?"
            params.append(cat)

        search = query.get('search', [None])[0]
        if search:
            sql += " AND (name LIKE ? OR description LIKE ?)"
            count_sql += " AND (name LIKE ? OR description LIKE ?)"
            params.append(f"%{search}%")
            params.append(f"%{search}%")

        cursor.execute(count_sql, params)
        total_count = cursor.fetchone()[0]

        sort = query.get('sort', ['default'])[0]
        if sort in ('date', 'latest'):
            sql += " ORDER BY id DESC"
        elif sort in ('popularity',):
            sql += " ORDER BY id ASC"
        elif sort in ('price-desc',):
            sql += " ORDER BY name DESC"
        elif sort in ('name_desc',):
            sql += " ORDER BY name DESC"
        else:
            sql += " ORDER BY name ASC"

        limit_param = query.get('limit', [None])[0]
        page_param = query.get('page', [None])[0]

        if page_param is not None or limit_param is not None:
            try:
                limit = int(limit_param) if limit_param else 16
                page = int(page_param) if page_param else 1
            except:
                limit = 16
                page = 1
            offset = (page - 1) * limit
            sql += f" LIMIT {limit} OFFSET {offset}"
            total_pages = (total_count + limit - 1) // limit if limit > 0 else 1
        else:
            page = 1
            limit = total_count
            total_pages = 1

        cursor.execute(sql, params)
        rows = cursor.fetchall()
        products = [dict(row) for row in rows]
        conn.close()
        self.send_json({
            "success": True,
            "count": len(products),
            "total": total_count,
            "page": page,
            "total_pages": total_pages,
            "products": products
        })

    def handle_get_product_by_slug(self, slug):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM products WHERE slug = ?", (slug,))
        row = cursor.fetchone()
        if row:
            product = dict(row)
            cursor.execute("SELECT * FROM products WHERE category_slug = ? AND id != ? LIMIT 4", (product["category_slug"], product["id"]))
            related = [dict(r) for r in cursor.fetchall()]
            product["related"] = related
            conn.close()
            self.send_json({"success": True, "product": product})
        else:
            conn.close()
            self.send_error_json("Product not found", 404)

    def handle_get_categories(self):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM categories ORDER BY id ASC")
        categories = [dict(row) for row in cursor.fetchall()]
        conn.close()
        self.send_json({"success": True, "categories": categories})

    def handle_get_quotes(self, query):
        conn = get_db()
        cursor = conn.cursor()
        status = query.get('status', [None])[0]
        if status:
            cursor.execute("SELECT * FROM quotes WHERE status = ? ORDER BY id DESC", (status,))
        else:
            cursor.execute("SELECT * FROM quotes ORDER BY id DESC")
        quotes = [dict(row) for row in cursor.fetchall()]
        conn.close()
        self.send_json({"success": True, "count": len(quotes), "quotes": quotes})

    def handle_export_quotes(self):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM quotes ORDER BY id DESC")
        rows = cursor.fetchall()
        conn.close()

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["ID", "Box Name", "Length", "Width", "Depth", "Client Name", "Email", "Phone", "Address", "Message", "Product Image", "Status", "Source", "Date"])
        for r in rows:
            writer.writerow([r["id"], r["box_name"], r["length"], r["width"], r["depth"], r["client_name"], r["email"], r["phone"], r["address"], r["message"], r["product_image"], r["status"], r["page_source"], r["created_at"]])
        
        csv_data = output.getvalue().encode('utf-8')
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Disposition", "attachment; filename=packaging_mindz_quotes.csv")
        self.send_header("Content-Length", str(len(csv_data)))
        self.end_headers()
        self.wfile.write(csv_data)

    def handle_post_quote(self):
        content_type = self.headers.get('Content-Type', '')

        box_name = ""
        length_val = None
        width_val = None
        depth_val = None
        client_name = ""
        address = ""
        email = ""
        phone = ""
        message = ""
        page_source = "Website Quote Form"
        image_path = ""

        if "multipart/form-data" in content_type:
            content_length = int(self.headers.get('Content-Length', 0))
            raw_body = self.rfile.read(content_length)
            payload = b"Content-Type: " + content_type.encode('utf-8') + b"\r\n\r\n" + raw_body
            msg = BytesParser(policy=default).parsebytes(payload)

            for part in msg.iter_parts():
                name = part.get_param('name', header='content-disposition')
                filename = part.get_filename()
                if filename:
                    ext = os.path.splitext(filename)[1].lower()
                    unique_name = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}{ext}"
                    dest = os.path.join(UPLOADS_DIR, unique_name)
                    file_bytes = part.get_payload(decode=True)
                    if file_bytes:
                        with open(dest, 'wb') as f:
                            f.write(file_bytes)
                        image_path = f"/uploads/{unique_name}"
                elif name:
                    raw_payload = part.get_payload(decode=True)
                    if raw_payload is not None:
                        val = raw_payload.decode('utf-8', errors='ignore').strip()
                        if name in ("box_name", "form_fields[name]", "name"):
                            box_name = val
                        elif name in ("length", "form_fields[field_b22512a]"):
                            length_val = val
                        elif name in ("width", "form_fields[field_03f5557]"):
                            width_val = val
                        elif name in ("depth", "form_fields[field_b5af2a8]"):
                            depth_val = val
                        elif name in ("client_name", "form_fields[field_ebf5166]", "full_name"):
                            client_name = val
                        elif name in ("address", "form_fields[field_f3e5887]"):
                            address = val
                        elif name in ("email", "form_fields[email]"):
                            email = val
                        elif name in ("phone", "form_fields[field_dd1bdd7]", "number"):
                            phone = val
                        elif name in ("message", "form_fields[message]"):
                            message = val
                        elif name in ("page_source", "referer_title"):
                            page_source = val

        else:
            content_length = int(self.headers.get('Content-Length', 0))
            raw_data = self.rfile.read(content_length)
            if "application/json" in content_type:
                data = json.loads(raw_data.decode('utf-8'))
                box_name = data.get("box_name", "")
                length_val = data.get("length")
                width_val = data.get("width")
                depth_val = data.get("depth")
                client_name = data.get("client_name") or data.get("name") or "Valued Client"
                address = data.get("address", "")
                email = data.get("email", "")
                phone = data.get("phone") or data.get("number", "")
                message = data.get("message", "")
                page_source = data.get("page_source", "Website Form")
            else:
                parsed = urllib.parse.parse_qs(raw_data.decode('utf-8'))
                box_name = parsed.get("box_name", [""])[0]
                client_name = parsed.get("client_name", ["Valued Client"])[0]
                email = parsed.get("email", [""])[0]
                phone = parsed.get("phone", [""])[0]
                address = parsed.get("address", [""])[0]
                message = parsed.get("message", [""])[0]

        try:
            length = float(length_val) if length_val else None
        except:
            length = None
        try:
            width = float(width_val) if width_val else None
        except:
            width = None
        try:
            depth = float(depth_val) if depth_val else None
        except:
            depth = None

        if not client_name:
            client_name = "Valued Client"

        if not email and not phone:
            self.send_error_json("Please provide at least an Email address or Phone number so we can send your quote.", 400)
            return

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('''
        INSERT INTO quotes (box_name, length, width, depth, product_image, client_name, address, email, phone, message, page_source, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')
        ''', (box_name, length, width, depth, image_path, client_name, address, email, phone, message, page_source))
        quote_id = cursor.lastrowid
        conn.commit()
        conn.close()

        self.send_json({
            "success": True,
            "message": "Thank you! Your quote request has been received. Our team will contact you shortly with custom pricing.",
            "quote_id": quote_id
        }, 201)

    def handle_update_quote_status(self, quote_id):
        content_length = int(self.headers.get('Content-Length', 0))
        raw = self.rfile.read(content_length).decode('utf-8')
        try:
            data = json.loads(raw)
            status = data.get("status", "new")
        except:
            parsed = urllib.parse.parse_qs(raw)
            status = parsed.get("status", ["new"])[0]

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE quotes SET status = ? WHERE id = ?", (status, quote_id))
        conn.commit()
        conn.close()
        self.send_json({"success": True, "message": f"Quote #{quote_id} status updated to {status}."})

    def handle_delete_quote(self, quote_id):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM quotes WHERE id = ?", (quote_id,))
        conn.commit()
        conn.close()
        self.send_json({"success": True, "message": f"Quote #{quote_id} deleted."})

import sys

def free_stale_port(port):
    if os.name == 'nt':
        try:
            import subprocess
            res = subprocess.check_output(f'netstat -ano | findstr :{port}', shell=True, stderr=subprocess.DEVNULL).decode('utf-8', errors='ignore')
            current_pid = os.getpid()
            for line in res.strip().splitlines():
                parts = line.strip().split()
                if len(parts) >= 5 and parts[1].endswith(f":{port}") and parts[3] == "LISTENING":
                    pid = int(parts[4])
                    if pid != current_pid and pid > 0:
                        subprocess.run(f'taskkill /F /PID {pid}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

def run_server():
    free_stale_port(PORT)
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:
        pass

    server_address = ("0.0.0.0", PORT)
    http.server.ThreadingHTTPServer.allow_reuse_address = True
    with http.server.ThreadingHTTPServer(server_address, PackagingMindzHandler) as httpd:
        print(f"============================================================")
        print(f" Packaging Mindz Server is LIVE at: http://localhost:{PORT}")
        print(f" Admin Submissions Dashboard at:    http://localhost:{PORT}/admin")
        print(f" Serving HTML5 / CSS3 / JS + SQLite backend")
        print(f"============================================================")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server.")

if __name__ == "__main__":
    run_server()

