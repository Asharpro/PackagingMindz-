/* =========================================================
   PACKAGING MINDZ - ADMIN DASHBOARD JAVASCRIPT
   Manage and review incoming quote requests and file uploads
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  const apiBase = window.API_BASE || (['5500', '5501', '3000'].includes(window.location.port) || window.location.protocol === 'file:' ? 'http://localhost:8000' : '');
  const tableBody = document.getElementById("quotesTableBody");
  const searchInput = document.getElementById("adminSearch");
  const statusFilter = document.getElementById("statusFilter");
  const totalCountEl = document.getElementById("totalCount");
  const newCountEl = document.getElementById("newCount");
  const inProgressCountEl = document.getElementById("inProgressCount");
  const completedCountEl = document.getElementById("completedCount");
  const messageModal = document.getElementById("messageModal");
  const modalText = document.getElementById("modalText");
  const modalClose = document.getElementById("modalClose");

  // Wire export button to apiBase if running under Live Server
  const exportBtn = document.querySelector('a[href*="/api/quotes/export"]');
  if (exportBtn && apiBase) {
    exportBtn.href = `${apiBase}/api/quotes/export`;
  }

  let allQuotes = [];

  async function loadQuotes() {
    try {
      const res = await fetch(`${apiBase}/api/quotes`);
      const data = await res.json();
      if (data.success) {
        allQuotes = data.quotes;
        updateStats();
        renderTable();
      }
    } catch (err) {
      console.error("Error loading quotes:", err);
      if (tableBody) {
        tableBody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 40px; color: #ef4444;">
          Cannot connect to backend server. Make sure <code>python server.py</code> is running in your terminal on port 8000.
        </td></tr>`;
      }
    }
  }

  function updateStats() {
    if (totalCountEl) totalCountEl.textContent = allQuotes.length;
    if (newCountEl) newCountEl.textContent = allQuotes.filter(q => q.status === "new").length;
    if (inProgressCountEl) inProgressCountEl.textContent = allQuotes.filter(q => q.status === "in_progress" || q.status === "quoted").length;
    if (completedCountEl) completedCountEl.textContent = allQuotes.filter(q => q.status === "completed").length;
  }

  function renderTable() {
    if (!tableBody) return;

    const query = searchInput ? searchInput.value.toLowerCase().trim() : "";
    const filter = statusFilter ? statusFilter.value : "all";

    const filtered = allQuotes.filter(q => {
      const matchesFilter = filter === "all" || q.status === filter;
      const matchesSearch = !query || 
        (q.client_name && q.client_name.toLowerCase().includes(query)) ||
        (q.email && q.email.toLowerCase().includes(query)) ||
        (q.phone && q.phone.toLowerCase().includes(query)) ||
        (q.box_name && q.box_name.toLowerCase().includes(query));
      return matchesFilter && matchesSearch;
    });

    if (filtered.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 40px; color: #64748b;">No quote submissions found.</td></tr>`;
      return;
    }

    tableBody.innerHTML = filtered.map(q => {
      const dims = [q.length ? `L: ${q.length}"` : '', q.width ? `W: ${q.width}"` : '', q.depth ? `D: ${q.depth}"` : ''].filter(Boolean).join(" x ") || "Custom";
      const fullImgUrl = q.product_image ? (q.product_image.startsWith("http") ? q.product_image : `${apiBase}${q.product_image}`) : null;
      const imgHtml = fullImgUrl 
        ? `<a href="${fullImgUrl}" target="_blank"><img src="${fullImgUrl}" class="thumb-preview" alt="Artwork" title="Click to view full image"></a>`
        : `<span style="color: #94a3b8; font-size: 12px;">No Image</span>`;
      
      const dateFormatted = new Date(q.created_at).toLocaleDateString("en-US", {
        month: "short", day: "numeric", hour: "2-digit", minute: "2-digit"
      });

      return `
        <tr>
          <td>#${q.id}</td>
          <td>
            <strong>${escapeHtml(q.client_name)}</strong><br>
            <small style="color: #64748b;">${escapeHtml(q.email || 'No email')}</small><br>
            <small style="color: #64748b;">${escapeHtml(q.phone || 'No phone')}</small>
          </td>
          <td>
            <strong>${escapeHtml(q.box_name || 'Standard Custom Box')}</strong><br>
            <small style="color: #64748b;">Dims: ${dims}</small>
          </td>
          <td>${imgHtml}</td>
          <td>
            <button class="action-btn" style="background: #e2e8f0; color: #334155;" onclick="viewMessage(${q.id})">
              Read Message
            </button>
          </td>
          <td>
            <select class="form-control" style="padding: 4px 8px; font-size: 12px; width: auto;" onchange="updateStatus(${q.id}, this.value)">
              <option value="new" ${q.status === 'new' ? 'selected' : ''}>New</option>
              <option value="in_progress" ${q.status === 'in_progress' ? 'selected' : ''}>In Progress</option>
              <option value="quoted" ${q.status === 'quoted' ? 'selected' : ''}>Quoted</option>
              <option value="completed" ${q.status === 'completed' ? 'selected' : ''}>Completed</option>
            </select>
          </td>
          <td style="white-space: nowrap; color: #64748b; font-size: 13px;">${dateFormatted}</td>
          <td>
            <button class="action-btn btn-delete" onclick="deleteQuote(${q.id})" title="Delete Quote">✕</button>
          </td>
        </tr>
      `;
    }).join("");
  }

  window.viewMessage = function (id) {
    const quote = allQuotes.find(q => q.id === id);
    if (quote && messageModal && modalText) {
      modalText.innerHTML = `
        <h3 style="margin-bottom: 12px;">Quote #${quote.id} from ${escapeHtml(quote.client_name)}</h3>
        <p><strong>Email:</strong> ${escapeHtml(quote.email || 'N/A')}</p>
        <p><strong>Phone:</strong> ${escapeHtml(quote.phone || 'N/A')}</p>
        <p><strong>Address:</strong> ${escapeHtml(quote.address || 'N/A')}</p>
        <p><strong>Box Name:</strong> ${escapeHtml(quote.box_name || 'N/A')}</p>
        <p><strong>Dimensions:</strong> Length: ${quote.length || '-'}, Width: ${quote.width || '-'}, Depth: ${quote.depth || '-'}</p>
        <p><strong>Source Page:</strong> ${escapeHtml(quote.page_source || 'N/A')}</p>
        <div style="margin-top: 16px; padding: 14px; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0;">
          <strong>Message:</strong><br>
          <div style="margin-top: 6px; white-space: pre-wrap;">${escapeHtml(quote.message || 'No additional message provided.')}</div>
        </div>
      `;
      messageModal.classList.add("active");
    }
  };

  window.updateStatus = async function (id, newStatus) {
    try {
      const res = await fetch(`${apiBase}/api/quotes/${id}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        const q = allQuotes.find(x => x.id === id);
        if (q) q.status = newStatus;
        updateStats();
      }
    } catch (err) {
      alert("Failed to update status.");
    }
  };

  window.deleteQuote = async function (id) {
    if (!confirm(`Are you sure you want to delete quote #${id}?`)) return;
    try {
      const res = await fetch(`${apiBase}/api/quotes/${id}`, { method: "DELETE" });
      if (res.ok) {
        allQuotes = allQuotes.filter(x => x.id !== id);
        updateStats();
        renderTable();
      }
    } catch (err) {
      alert("Failed to delete quote.");
    }
  };

  if (modalClose && messageModal) {
    modalClose.addEventListener("click", () => messageModal.classList.remove("active"));
    messageModal.addEventListener("click", (e) => {
      if (e.target === messageModal) messageModal.classList.remove("active");
    });
  }

  if (searchInput) searchInput.addEventListener("input", renderTable);
  if (statusFilter) statusFilter.addEventListener("change", renderTable);

  function escapeHtml(text) {
    if (!text) return "";
    return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  loadQuotes();
});
