/* =========================================================
   PACKAGING MINDZ - MAIN JAVASCRIPT
   Interactive components, mega menu, slider, lightbox, FAQ
   ========================================================= */

// Auto-detect backend port when running under VS Code Live Server (port 5500/5501)
window.API_BASE = (['5500', '5501', '3000'].includes(window.location.port) || window.location.protocol === 'file:')
  ? 'http://localhost:8000'
  : '';

document.addEventListener("DOMContentLoaded", function () {
  // 1. Mobile Menu Drawer Toggle
  const mobileToggle = document.getElementById("mobileToggle");
  const mainNav = document.getElementById("mainNav");
  if (mobileToggle && mainNav) {
    mobileToggle.addEventListener("click", function () {
      mainNav.classList.toggle("open");
    });
  }

  // 2. Mobile Mega Menu Dropdown Toggle
  const categoryNavItem = document.getElementById("categoryNavItem");
  if (categoryNavItem) {
    const categoryLink = categoryNavItem.querySelector(".nav-link");
    if (categoryLink) {
      categoryLink.addEventListener("click", function (e) {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          categoryNavItem.classList.toggle("open");
        }
      });
    }
  }

  // 3. Lightbox functionality for the Packaging Marquee Slider
  const sliderSlides = document.querySelectorAll(".pm-slide");
  const lightbox = document.getElementById("pmLightbox");
  const lightboxImg = document.getElementById("pmLightboxImage");
  const lightboxClose = document.getElementById("pmLightboxClose");

  if (lightbox && lightboxImg) {
    sliderSlides.forEach(slide => {
      slide.addEventListener("click", function () {
        const img = this.querySelector("img");
        if (img) {
          lightboxImg.src = img.src;
          lightboxImg.alt = img.alt || "Packaging Preview";
          lightbox.classList.add("active");
          document.body.style.overflow = "hidden";
        }
      });
    });

    const closeLightbox = () => {
      lightbox.classList.remove("active");
      document.body.style.overflow = "";
      setTimeout(() => {
        if (!lightbox.classList.contains("active")) {
          lightboxImg.src = "";
        }
      }, 300);
    };

    if (lightboxClose) {
      lightboxClose.addEventListener("click", closeLightbox);
    }

    lightbox.addEventListener("click", function (e) {
      if (e.target === lightbox) {
        closeLightbox();
      }
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && lightbox.classList.contains("active")) {
        closeLightbox();
      }
    });
  }

  // 4. Interactive FAQ Accordion
  const faqItems = document.querySelectorAll(".faq-item, .accordion-item");
  faqItems.forEach(item => {
    const header = item.querySelector(".faq-question, .accordion-header");
    if (header) {
      header.addEventListener("click", function () {
        const isActive = item.classList.contains("active");

        // Close other accordion items
        faqItems.forEach(otherItem => {
          if (otherItem !== item) {
            otherItem.classList.remove("active");
            const icon = otherItem.querySelector(".faq-icon, .accordion-icon");
            if (icon) icon.textContent = "+";
          }
        });

        // Toggle current item
        if (isActive) {
          item.classList.remove("active");
          const icon = item.querySelector(".faq-icon, .accordion-icon");
          if (icon) icon.textContent = "+";
        } else {
          item.classList.add("active");
          const icon = item.querySelector(".faq-icon, .accordion-icon");
          if (icon) icon.textContent = "−";
        }
      });
    }
  });

  // 5. Dynamic Footer Year
  const yearEl = document.getElementById("currentYear");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
});
