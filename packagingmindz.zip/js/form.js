/* =========================================================
   PACKAGING MINDZ - FORM HANDLER
   Handles AJAX quote requests, file uploads, and SQLite responses
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  const quoteForms = document.querySelectorAll(".quote-form");

  quoteForms.forEach(form => {
    const fileInput = form.querySelector('input[type="file"]');
    const uploadZone = form.querySelector(".file-upload-zone");
    const filePreview = form.querySelector(".file-preview");
    const alertBox = form.querySelector(".form-alert");
    const submitBtn = form.querySelector('button[type="submit"]');

    // 1. File Upload Dropzone Handling
    if (uploadZone && fileInput) {
      uploadZone.addEventListener("click", () => fileInput.click());

      uploadZone.addEventListener("dragover", (e) => {
        e.preventDefault();
        uploadZone.classList.add("dragover");
      });

      uploadZone.addEventListener("dragleave", () => {
        uploadZone.classList.remove("dragover");
      });

      uploadZone.addEventListener("drop", (e) => {
        e.preventDefault();
        uploadZone.classList.remove("dragover");
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          fileInput.files = e.dataTransfer.files;
          updateFilePreview(fileInput.files[0]);
        }
      });

      fileInput.addEventListener("change", () => {
        if (fileInput.files && fileInput.files.length > 0) {
          updateFilePreview(fileInput.files[0]);
        }
      });
    }

    function updateFilePreview(file) {
      if (filePreview && file) {
        filePreview.style.display = "block";
        filePreview.textContent = `✓ Selected File: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
      }
    }

    // 2. Form Submission via AJAX to /api/quote
    form.addEventListener("submit", async function (e) {
      e.preventDefault();

      if (alertBox) {
        alertBox.style.display = "none";
        alertBox.className = "form-alert";
      }

      // Validate required inputs
      const emailInput = form.querySelector('input[name="email"], input[name="form_fields[email]"]');
      const phoneInput = form.querySelector('input[name="phone"], input[name="form_fields[field_dd1bdd7]"]');

      if ((!emailInput || !emailInput.value.trim()) && (!phoneInput || !phoneInput.value.trim())) {
        showAlert("Please provide at least an Email address or Phone number so we can contact you.", "error");
        return;
      }

      const originalBtnText = submitBtn ? submitBtn.innerHTML : "Send";
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="spinner"></span> Processing...`;
      }

      try {
        const formData = new FormData(form);
        const apiBase = window.API_BASE || (['5500', '5501', '3000'].includes(window.location.port) || window.location.protocol === 'file:' ? 'http://localhost:8000' : '');

        const response = await fetch(`${apiBase}/api/quote`, {
          method: "POST",
          body: formData
        });

        const result = await response.json();

        if (response.ok && result.success) {
          showAlert(result.message || "Thank you! Your quote request has been received. Our team will contact you shortly.", "success");
          form.reset();
          if (filePreview) filePreview.style.display = "none";
        } else {
          showAlert(result.error || "Something went wrong. Please check your information and try again.", "error");
        }
      } catch (err) {
        if (window.location.port === "5500" || window.location.port === "5501") {
          showAlert("Could not reach backend server. Please make sure `python server.py` is running in your terminal on port 8000!", "error");
        } else {
          showAlert("Network connection error. Please try again or call us at (626) 323-6829.", "error");
        }
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalBtnText;
        }
      }
    });

    function showAlert(msg, type) {
      if (alertBox) {
        alertBox.textContent = msg;
        alertBox.className = `form-alert ${type} show`;
        alertBox.style.display = "block";
        alertBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
      } else {
        alert(msg);
      }
    }
  });
});
