/* =========================================================
   PACKAGING MINDZ - SHOP PAGE JAVASCRIPT (MATCHING LIVE SITE)
   Renders 16 products per page with live sorting & pagination
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  const productsContainer = document.getElementById("shopProductsGrid");
  const orderBySelect = document.getElementById("shopOrderBy");
  const paginationContainer = document.getElementById("shopPagination");

  const urlParams = new URLSearchParams(window.location.search);
  let currentPage = parseInt(urlParams.get("page")) || 1;
  let currentSort = urlParams.get("orderby") || "menu_order";

  if (orderBySelect) {
    orderBySelect.value = currentSort;
    orderBySelect.addEventListener("change", function () {
      currentSort = this.value;
      currentPage = 1;
      updateUrlAndLoad();
    });
  }

  function updateUrlAndLoad() {
    const newUrl = new URL(window.location);
    newUrl.searchParams.set("page", currentPage);
    if (currentSort !== "menu_order") {
      newUrl.searchParams.set("orderby", currentSort);
    } else {
      newUrl.searchParams.delete("orderby");
    }
    window.history.pushState({}, "", newUrl);
    loadProducts();
  }

  window.addEventListener("popstate", function () {
    const params = new URLSearchParams(window.location.search);
    currentPage = parseInt(params.get("page")) || 1;
    currentSort = params.get("orderby") || "menu_order";
    if (orderBySelect) orderBySelect.value = currentSort;
    loadProducts();
  });

  async function loadProducts() {
    if (!productsContainer) return;
    productsContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 60px 20px;"><span class="spinner" style="border-color: #b2881c; border-top-color: transparent; width: 32px; height: 32px; display: inline-block;"></span><p style="margin-top: 14px; color: #64748b; font-size: 15px;">Loading products...</p></div>`;

    try {
      const apiBase = window.API_BASE || (['5500', '5501', '3000'].includes(window.location.port) || window.location.protocol === 'file:' ? 'http://localhost:8000' : '');
      const res = await fetch(`${apiBase}/api/products?page=${currentPage}&limit=16&sort=${encodeURIComponent(currentSort)}`);
      const data = await res.json();

      if (data.success && data.products && data.products.length > 0) {
        renderProducts(data.products);
        renderPagination(data.page, data.total_pages || 5);
      } else {
        productsContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 60px; color: #64748b; font-size: 16px;">No products found on this page.</div>`;
        if (paginationContainer) paginationContainer.innerHTML = "";
      }
    } catch (err) {
      console.error("Error loading products:", err);
      productsContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 60px; color: #ef4444;">Failed to load products. Please try again.</div>`;
    }
  }

  function renderProducts(products) {
    productsContainer.innerHTML = products.map(p => `
      <div class="shop-product-card">
        <a href="/product/${p.slug}" class="shop-product-thumb" title="${p.name}">
          <img src="${p.thumbnail || p.image || '/images/cat_retail.png'}" alt="${p.name}" loading="lazy">
        </a>
        <div class="shop-product-body">
          <h2 class="shop-product-title">
            <a href="/product/${p.slug}">${p.name}</a>
          </h2>
          <a href="/product/${p.slug}" class="shop-product-btn">
            Read more
          </a>
        </div>
      </div>
    `).join("");
  }

  function renderPagination(page, totalPages) {
    if (!paginationContainer) return;
    if (totalPages <= 1) {
      paginationContainer.innerHTML = "";
      return;
    }

    let items = [];
    const maxPagesToShow = 5;
    const startPage = Math.max(1, Math.min(page - 2, totalPages - maxPagesToShow + 1));
    const endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);

    for (let i = startPage; i <= endPage; i++) {
      if (i === page) {
        items.push(`<li><span class="page-numbers current" aria-current="page">${i}</span></li>`);
      } else {
        items.push(`<li><a class="page-numbers" href="?page=${i}" data-page="${i}">${i}</a></li>`);
      }
    }

    if (page < totalPages) {
      items.push(`<li><a class="next page-numbers" href="?page=${page + 1}" data-page="${page + 1}">&rarr;</a></li>`);
    }

    paginationContainer.innerHTML = `
      <ul class="shop-pagination">
        ${items.join("")}
      </ul>
    `;

    paginationContainer.querySelectorAll("a.page-numbers").forEach(link => {
      link.addEventListener("click", function (e) {
        e.preventDefault();
        const targetPage = parseInt(this.dataset.page);
        if (targetPage && targetPage !== currentPage) {
          currentPage = targetPage;
          updateUrlAndLoad();
          const catalogSection = document.getElementById("shopCatalogSection");
          if (catalogSection) {
            catalogSection.scrollIntoView({ behavior: "smooth" });
          }
        }
      });
    });
  }

  loadProducts();
});
