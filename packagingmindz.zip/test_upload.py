import urllib.request
import json
import sqlite3
import os
import uuid
import threading
import time
from server import DB_PATH, UPLOADS_DIR, run_server

def ensure_server():
    try:
        urllib.request.urlopen("http://127.0.0.1:8000/api/categories", timeout=1)
    except Exception:
        t = threading.Thread(target=run_server, daemon=True)
        t.start()
        time.sleep(1)

def test_multipart_upload():
    ensure_server()
    boundary = "----WebKitFormBoundary" + uuid.uuid4().hex
    
    fields = {
        "box_name": "Rigid Drawer Box With Spot UV",
        "length": "8.5",
        "width": "5.0",
        "depth": "2.0",
        "client_name": "Acme Cosmetics Corp",
        "address": "San Francisco, CA 94105",
        "email": "orders@acmecosmetics.com",
        "phone": "(415) 555-8899",
        "message": "Please quote 2500 units with custom velvet insert.",
        "page_source": "Contact Form with Artwork"
    }

    test_image_data = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15c4\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
    file_field_name = "product_image"
    filename = "box_sample_artwork.png"

    body = bytearray()
    for k, v in fields.items():
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(f'Content-Disposition: form-data; name="{k}"\r\n\r\n'.encode())
        body.extend(f"{v}\r\n".encode())

    # Add file
    body.extend(f"--{boundary}\r\n".encode())
    body.extend(f'Content-Disposition: form-data; name="{file_field_name}"; filename="{filename}"\r\n'.encode())
    body.extend(b"Content-Type: image/png\r\n\r\n")
    body.extend(test_image_data)
    body.extend(b"\r\n")
    body.extend(f"--{boundary}--\r\n".encode())

    req = urllib.request.Request(
        "http://127.0.0.1:8000/api/quote",
        data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"}
    )

    with urllib.request.urlopen(req, timeout=5) as res:
        assert res.status == 201, f"Expected 201, got {res.status}"
        data = json.loads(res.read().decode('utf-8'))
        assert data["success"] is True
        quote_id = data["quote_id"]
        print(f"Multipart submission succeeded! Quote ID: {quote_id}")

    # Verify database entry has file path
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT box_name, product_image, client_name FROM quotes WHERE id = ?", (quote_id,))
    row = c.fetchone()
    conn.close()

    assert row is not None
    assert row[0] == "Rigid Drawer Box With Spot UV"
    assert row[1].startswith("/uploads/")
    assert row[2] == "Acme Cosmetics Corp"
    
    saved_file_name = row[1].replace("/uploads/", "")
    saved_path = os.path.join(UPLOADS_DIR, saved_file_name)
    assert os.path.exists(saved_path), f"File {saved_path} does not exist"
    print(f"File upload verified on disk at: {saved_path} (Size: {os.path.getsize(saved_path)} bytes)")
    print("ALL MULTIPART FILE UPLOAD TESTS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    test_multipart_upload()
