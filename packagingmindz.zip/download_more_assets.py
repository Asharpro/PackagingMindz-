import os
import urllib.request

DEST_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "images")
os.makedirs(DEST_DIR, exist_ok=True)

IMAGES = [
    ("hero-section-image.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/hero-section-image.webp"),
    ("mat_cardboard.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/word-image-2702-2.webp"),
    ("mat_rigid.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/Rigid-Gift-Box.webp"),
    ("mat_kraft.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/Kraft-Paper-Pouch.webp"),
    ("mat_corrugated.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/Corrugated-Boxes.webp"),
    ("finish_matte.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/ChatGPT-Image-Aug-25-2026-03_34_02-AM.webp"),
    ("finish_gloss.png", "https://packagingmindz.com/wp-content/uploads/2026/08/ChatGPT-Image-Aug-25-2026-03_31_33-AM.png"),
    ("finish_spotuv.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/666f43fd-0244-40a1-90f3-f2b1bd47c70b.webp"),
    ("finish_foil.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/676e48f1-bc0b-4f1d-b8a8-58c91dbdb780.webp"),
    ("finish_emboss.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/ChatGPT-Image-Aug-25-2026-03_46_36-AM.webp"),
    ("finish_aqueous.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/ChatGPT-Image-Aug-25-2026-03_52_35-AM.webp"),
]

headers = {'User-Agent': 'Mozilla/5.0'}
for fname, url in IMAGES:
    target = os.path.join(DEST_DIR, fname)
    if not os.path.exists(target):
        try:
            print(f"Downloading {fname}...")
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as r, open(target, 'wb') as f:
                f.write(r.read())
            print(f"Saved {fname} ({os.path.getsize(target)} bytes)")
        except Exception as e:
            print(f"Failed to download {fname}: {e}")
print("Done downloading images.")
