@echo off
title Packaging Mindz Web Server
echo ========================================================
echo   Starting Packaging Mindz Web Server (HTML5 + SQLite)
echo ========================================================
echo Opening http://localhost:8000 in your browser...
start http://localhost:8000
echo Running Python backend server on port 8000...
python server.py
pause
