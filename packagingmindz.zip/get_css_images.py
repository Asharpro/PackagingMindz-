import urllib.request
import re

urls = [
    'https://packagingmindz.com/wp-content/uploads/elementor/css/post-47.css',
    'https://packagingmindz.com/wp-content/uploads/elementor/css/post-146.css',
    'https://packagingmindz.com/wp-content/uploads/elementor/css/post-209.css',
    'https://packagingmindz.com/wp-content/uploads/elementor/css/post-6.css'
]

headers = {'User-Agent': 'Mozilla/5.0'}
all_images = set()

for u in urls:
    try:
        req = urllib.request.Request(u, headers=headers)
        with urllib.request.urlopen(req) as resp:
            css = resp.read().decode('utf-8', errors='ignore')
            found = re.findall(r'https?://[^\s\)\"\']+\.(?:png|jpg|jpeg|webp|avif)', css)
            all_images.update(found)
    except Exception as e:
        print(f"Error reading {u}: {e}")

print(f"Total image URLs found: {len(all_images)}")
for img in sorted(all_images):
    print(img)
