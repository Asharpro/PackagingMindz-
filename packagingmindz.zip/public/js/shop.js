/* =========================================================
   PACKAGING MINDZ - SHOP & CATALOG JAVASCRIPT
   Renders and filters products from SQLite database
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  const productsContainer = document.getElementById("productsGrid");
  const filterBtns = document.querySelectorAll(".filter-btn");
  const sortSelect = document.getElementById("sortSelect");
  const searchInput = document.getElementById("shopSearch");
  const productCountEl = document.getElementById("productCount");

  let activeCategory = "all";
  let activeSort = "default";
  let searchQuery = "";

  // Check URL query param for pre-selected category
  const urlParams = new URLSearchParams(window.location.search);
  const catParam = urlParams.get("category");
  if (catParam) {
    activeCategory = catParam;
    filterBtns.forEach(btn => {
      if (btn.dataset.category === catParam) {
        btn.classList.add("active");
      } else {
        btn.classList.remove("active");
      }
    });
  }

  async function loadProducts() {
    if (!productsContainer) return;
    productsContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px;"><span class="spinner" style="border-color: #b2881c; border-top-color: transparent; width: 28px; height: 28px;"></span> Loading products...</div>`;

    try {
      const apiBase = window.API_BASE || (['5500', '5501', '3000'].includes(window.location.port) || window.location.protocol === 'file:' ? 'http://localhost:8000' : '');
      let url = `${apiBase}/api/products?sort=${activeSort}`;
      if (activeCategory && activeCategory !== "all") {
        url += `&category=${encodeURIComponent(activeCategory)}`;
      }
      if (searchQuery) {
        url += `&search=${encodeURIComponent(searchQuery)}`;
      }

      const res = await fetch(url);
      const data = await res.json();

      if (data.success && data.products) {
        renderProducts(data.products);
        if (productCountEl) {
          productCountEl.textContent = `Showing all ${data.products.length} products`;
        }
      } else {
        productsContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #64748b;">No products found matching your selection.</div>`;
      }
    } catch (err) {
      productsContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #ef4444;">Failed to load products. Please refresh the page.</div>`;
    }
  }

  function renderProducts(products) {
    if (products.length === 0) {
      productsContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #64748b;">No products found matching your criteria.</div>`;
      return;
    }

    productsContainer.innerHTML = products.map(p => `
      <div class="product-card">
        <a href="/product/${p.slug}" class="product-card-img">
          <img src="${p.thumbnail || p.image || 'https://packagingmindz.com/wp-content/uploads/2026/08/packaging-mindz-1-1-1-1024x427.png'}" alt="${p.name}" loading="lazy">
        </a>
        <div class="product-card-body">
          <h3 class="product-title">
            <a href="/product/${p.slug}">${p.name}</a>
          </h3>
          <a href="/product/${p.slug}" class="btn btn-primary btn-sm shimmer-btn">
            Get Quote
          </a>
        </div>
      </div>
    `).join("");
  }

  // Filter Buttons
  filterBtns.forEach(btn => {
    btn.addEventListener("click", function () {
      filterBtns.forEach(b => b.classList.remove("active"));
      this.classList.add("active");
      activeCategory = this.dataset.category;
      loadProducts();
    });
  });

  // Sort Selector
  if (sortSelect) {
    sortSelect.addEventListener("change", function () {
      activeSort = this.value;
      loadProducts();
    });
  }

  // Search Input
  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener("input", function () {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        searchQuery = searchInput.value.trim();
        loadProducts();
      }, 350);
    });
  }

  loadProducts();
});
