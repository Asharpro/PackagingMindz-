# Packaging Mindz — HTML5 / CSS3 / JavaScript / SQLite Platform

A fast, lightweight, modernized conversion of [packagingmindz.com](https://packagingmindz.com/) from WordPress/Elementor into clean **HTML5, CSS3, Vanilla JavaScript, Python, and an SQLite database**.

---

## 🌟 Key Features

1. **Exact Brand Design & Components**:
   - **Top Announcement Bar**: "Free Prototype Design For All Custom Orders | Call: (626) 323-6829"
   - **Header & Mega Menu**: Full navigation with visual Category Mega Menu displaying 8 packaging categories with thumbnail images and smooth entrance transitions.
   - **Responsive Mobile Drawer**: Hamburger menu with collapsible submenus for tablets and mobile phones.
   - **Hero Section**: Exact typography with gold highlights (`#b2881c`), CTA quote button, and click-to-call link.
   - **Infinite Packaging Marquee Slider**: Smooth continuous horizontal carousel (`@keyframes pmScroll 35s linear infinite`) with pause-on-hover.
   - **Image Lightbox Modal**: High-res zoom modal with ESC key and backdrop dismissal.
   - **3D Flip Material Boxes**: Interactive push/flip cards on the Materials section showcasing Cardboard, Rigid Board, Kraft, and Corrugated specifications.
   - **6 Premium Finishes Cards**: Matte, Gloss, Spot UV, Hot Foil, Embossing, and Aqueous coating cards.
   - **Interactive FAQ Accordion**: Expand/collapse with animated `+` and `−` icon toggles.
   - **Shimmer / Shine Button Hover Effects**: Animated gradient sweep across buttons on hover.
   - **Floating Chaty Widget**: Quick-connect buttons for WhatsApp and Direct Phone Call.

2. **Complete Catalog & Category Filtering**:
   - Pre-seeded with **68 live products** and **8 packaging categories** in SQLite.
   - Shop page with live category filters, search input, and sorting (popularity, latest, default).
   - Single product detail template with dynamic routing, gallery, overview, specifications, and related products.

3. **Fully Functional Quote Forms with SQLite Storage**:
   - Working "Get Instant Quote" forms on **Contact Us** and **Single Product** pages.
   - Fields: Box Name, Length, Width, Depth, Artwork File Upload, Client Name, Address, Email, Phone, and Quantity/Message.
   - **File Upload Support**: Drag-and-drop file upload zone saving user-uploaded artwork/dielines into `uploads/`.
   - Live in-page validation, loading spinner, and success/error alert toasts without page reload.
   - Submissions persist directly in `database.sqlite` in the `quotes` table.

4. **Admin Submissions Dashboard (`/admin`)**:
   - View all submitted quotes in real-time.
   - Filter by status: *New*, *In Progress*, *Quoted*, *Completed*.
   - Live search by client name, email, phone, or box name.
   - Inspect uploaded artwork/images and read full client notes.
   - Update inquiry status with one click.
   - **Export to CSV**: Download all quote inquiries for CRM / Excel analysis.

---

## 🚀 How to Run

### 1. Start the Server
Open PowerShell or Command Prompt in this folder and run:
```powershell
python server.py
```

The server will start on port 8000:
- **Website Homepage**: [http://localhost:8000](http://localhost:8000)
- **Shop Catalog**: [http://localhost:8000/shop](http://localhost:8000/shop)
- **Contact Us & Quote Form**: [http://localhost:8000/contact-us](http://localhost:8000/contact-us)
- **Product Categories**: [http://localhost:8000/category](http://localhost:8000/category)
- **Admin Submissions Dashboard**: [http://localhost:8000/admin](http://localhost:8000/admin)

### 2. Run Automated Tests
```powershell
python test_system.py
```
Tests database tables, seeded counts, endpoints, form submission, and SQLite persistence.

### 3. Test File Uploads
```powershell
python test_upload.py
```
Simulates a client uploading custom artwork via multipart form data and verifies file persistence on disk.

---

## 📂 Project Directory Layout

```
packagingmindz/
├── server.py                 # Multi-threaded Python server with SQLite & multipart upload support
├── init_db.py                # Database initializer & sitemap scraper/seeder
├── test_system.py            # Automated test suite
├── test_upload.py            # File upload test suite
├── database.sqlite           # SQLite database (quotes, products, categories)
├── uploads/                  # Storage folder for client-uploaded box artwork & dielines
├── public/                   # Static web assets
│   ├── index.html            # Home page
│   ├── about-us.html         # About Us page
│   ├── shop.html             # Shop / Catalog with category filters & search
│   ├── product.html          # Dynamic Product Detail template with embedded quote form
│   ├── contact-us.html       # Contact Us page with full Instant Quote form & map embed
│   ├── category.html         # Categories overview and filtered view
│   ├── blog.html             # Blog insights page
│   ├── privacy-policy.html   # Privacy policy
│   ├── terms-and-conditions.html # Terms & conditions
│   ├── admin.html            # Admin dashboard for viewing and managing quote inquiries
│   ├── css/
│   │   ├── style.css         # Main stylesheet (layout, typography, colors, responsive design)
│   │   ├── animations.css    # Transitions, button shimmer, marquee keyframes, 3D flip card
│   │   └── admin.css         # Admin dashboard styles
│   ├── js/
│   │   ├── main.js           # Header mega menu, mobile navigation, marquee slider, lightbox, FAQ accordion
│   │   ├── form.js           # AJAX form submitter with file upload, validation & toast alerts
│   │   ├── shop.js           # Product catalog filtering, searching, and sorting
│   │   └── admin.js          # Admin dashboard quote manager, status updater & CSV exporter
│   └── images/               # Image assets folder
```

---

## 🗄️ SQLite Database Schema

### `quotes` Table
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PRIMARY KEY | Unique inquiry ID |
| `box_name` | TEXT | Box model / product name |
| `length` | REAL | Length in inches |
| `width` | REAL | Width in inches |
| `depth` | REAL | Depth in inches |
| `product_image` | TEXT | Path to uploaded file (e.g. `/uploads/filename.png`) |
| `client_name` | TEXT | Client's full name |
| `address` | TEXT | Shipping city, state, or address |
| `email` | TEXT | Client email address |
| `phone` | TEXT | Client phone / WhatsApp number |
| `message` | TEXT | Project requirements & estimated quantity |
| `page_source` | TEXT | Page where inquiry originated |
| `status` | TEXT | `new`, `in_progress`, `quoted`, `completed` |
| `created_at` | DATETIME | Timestamp of submission |

### `products` Table
Pre-populated with 68 custom packaging products mapped to their respective categories, with high-resolution image links, specifications, and descriptions.

### `categories` Table
Pre-populated with 8 core packaging categories:
1. Retail Boxes
2. Printed Rigid Boxes
3. Printed Paper Bags
4. Jewelry Packaging
5. Food Packaging Boxes
6. Ecommerce Packaging Boxes
7. Cosmetic Boxes
8. Apparel Packaging
