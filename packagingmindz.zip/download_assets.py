import os
import urllib.request

IMAGES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "public", "images")
os.makedirs(IMAGES_DIR, exist_ok=True)

ASSETS = [
    ("logo.png", "https://packagingmindz.com/wp-content/uploads/2026/08/packaging-mindz-1-1-1-1024x427.png"),
    ("favicon.png", "https://packagingmindz.com/wp-content/uploads/2026/08/cropped-packaging-mindz-1-1-1-scaled-1-32x32.png"),
    ("hero_boxes.png", "https://packagingmindz.com/wp-content/uploads/2026/08/eecc3453-594b-4288-a95d-fc5c04c1bc69-768x1024.png"),
    ("about_story.png", "https://packagingmindz.com/wp-content/uploads/2026/08/225b619f-ed8a-4a3f-abcd-da4381074bae-768x1024.png"),
    ("custom_spec.webp", "https://packagingmindz.com/wp-content/uploads/2026/08/3e61e4ec-aba2-4cc2-9ef8-d2a30c2df19d-1024x683.webp"),
    ("faq_box.png", "https://packagingmindz.com/wp-content/uploads/2026/08/9958f74b-7733-4210-9ae7-d20dd9117547-768x1024.png"),
    ("cat_retail.png", "https://packagingmindz.com/wp-content/uploads/2026/08/Retial-Ridge-boxes-300x300.png"),
    ("cat_rigid.png", "https://packagingmindz.com/wp-content/uploads/2026/09/Untitled-design-300x300.png"),
    ("cat_bags.png", "https://packagingmindz.com/wp-content/uploads/2026/08/Printed-Paper-Bags-catagoes-image-2-300x300.png"),
    ("cat_jewelry.png", "https://packagingmindz.com/wp-content/uploads/2026/08/Jewelry-Packaging-catagoies-300x300.png"),
    ("cat_food.png", "https://packagingmindz.com/wp-content/uploads/2026/08/23931223-9537-4a03-8166-29463ce50c7e-300x300.png"),
    ("cat_ecommerce.png", "https://packagingmindz.com/wp-content/uploads/2026/09/Untitled-design-1-300x300.png"),
    ("cat_cosmetic.png", "https://packagingmindz.com/wp-content/uploads/2026/08/Cosmetic-Boxes-category-300x300.png"),
    ("cat_apparel.png", "https://packagingmindz.com/wp-content/uploads/2026/08/40a7cc8a-2b75-476a-9272-69f276a2041a-300x300.png"),
]

def download_assets():
    headers = {'User-Agent': 'Mozilla/5.0'}
    for name, url in ASSETS:
        dest = os.path.join(IMAGES_DIR, name)
        if not os.path.exists(dest):
            try:
                print(f"Downloading {name}...")
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=10) as resp, open(dest, 'wb') as out:
                    out.write(resp.read())
            except Exception as e:
                print(f"Failed to download {name}: {e}")
    print("Asset download process completed.")

if __name__ == "__main__":
    download_assets()
