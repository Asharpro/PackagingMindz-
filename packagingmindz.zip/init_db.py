import sqlite3
import os
import re
import urllib.request
import xml.etree.ElementTree as ET

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "database.sqlite")

CATEGORIES_DATA = [
    {
        "name": "Retail Boxes",
        "slug": "retails-boxes",
        "count": 12,
        "image": "https://packagingmindz.com/wp-content/uploads/2026/08/Retial-Ridge-boxes-300x300.png",
        "description": "High quality custom printed retail boxes tailored to present your brand and protect products on shelves."
    },
    {
        "name": "Printed Rigid Boxes",
        "slug": "printed-rigid-boxes",
        "count": 6,
        "image": "https://packagingmindz.com/wp-content/uploads/2026/09/Untitled-design-300x300.png",
        "description": "Dense, heavyweight luxury rigid boxes engineered for premium unboxing experiences."
    },
    {
        "name": "Printed Paper Bags",
        "slug": "printed-paper-bags",
        "count": 10,
        "image": "https://packagingmindz.com/wp-content/uploads/2026/08/Printed-Paper-Bags-catagoes-image-2-300x300.png",
        "description": "Custom printed paper gift and shopping bags with durable handles and vibrant printing."
    },
    {
        "name": "Jewelry Packaging",
        "slug": "jewelry-packaging",
        "count": 6,
        "image": "https://packagingmindz.com/wp-content/uploads/2026/08/Jewelry-Packaging-catagoies-300x300.png",
        "description": "Elegant jewelry boxes, pouches, and inserts crafted for rings, necklaces, bracelets, and earrings."
    },
    {
        "name": "Food Packaging Boxes",
        "slug": "food-packaging-boxes",
        "count": 15,
        "image": "https://packagingmindz.com/wp-content/uploads/2026/08/23931223-9537-4a03-8166-29463ce50c7e-300x300.png",
        "description": "Food-grade certified bakery, cake, takeout, and burger boxes designed to preserve freshness."
    },
    {
        "name": "Ecommerce Packaging Boxes",
        "slug": "ecommerce-packaging-boxes",
        "count": 9,
        "image": "https://packagingmindz.com/wp-content/uploads/2026/09/Untitled-design-1-300x300.png",
        "description": "Durable corrugated mailer boxes, bubble wraps, and protective packaging built for shipping safety."
    },
    {
        "name": "Cosmetic Boxes",
        "slug": "cosmetic-boxes",
        "count": 6,
        "image": "https://packagingmindz.com/wp-content/uploads/2026/08/Cosmetic-Boxes-category-300x300.png",
        "description": "Sophisticated cosmetic packaging for perfumes, creams, skincare, and beauty accessories."
    },
    {
        "name": "Apparel Packaging",
        "slug": "apparel-packaging",
        "count": 4,
        "image": "https://packagingmindz.com/wp-content/uploads/2026/08/40a7cc8a-2b75-476a-9272-69f276a2041a-300x300.png",
        "description": "Custom apparel boxes, garment mailers, and folding cartons for clothing, shoes, and textiles."
    }
]

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Create quotes table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        box_name TEXT,
        length REAL,
        width REAL,
        depth REAL,
        product_image TEXT,
        client_name TEXT NOT NULL,
        address TEXT,
        email TEXT NOT NULL,
        phone TEXT,
        message TEXT,
        page_source TEXT DEFAULT 'Contact Us',
        status TEXT DEFAULT 'new',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Create categories table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        count INTEGER DEFAULT 0,
        image TEXT,
        description TEXT
    )
    ''')

    # Create products table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        category_slug TEXT NOT NULL,
        category_name TEXT NOT NULL,
        thumbnail TEXT,
        image TEXT,
        description TEXT,
        specifications TEXT,
        featured INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Seed categories
    for cat in CATEGORIES_DATA:
        cursor.execute('''
        INSERT OR REPLACE INTO categories (name, slug, count, image, description)
        VALUES (?, ?, ?, ?, ?)
        ''', (cat["name"], cat["slug"], cat["count"], cat["image"], cat["description"]))

    conn.commit()
    conn.close()
    print("Database tables created and categories seeded.")

def slug_to_title(slug):
    words = slug.split('-')
    cleaned = []
    for w in words:
        if w.lower() in ['to', 'and', 'for', 'a', 'in', 'of', 'with']:
            cleaned.append(w.lower())
        else:
            cleaned.append(w.capitalize())
    title = " ".join(cleaned)
    if title:
        title = title[0].upper() + title[1:]
    return title

def guess_category(slug):
    slug_lower = slug.lower()
    if any(k in slug_lower for k in ['food', 'cake', 'bakery', 'burger', 'pizza', 'sweet', 'dates', 'chocolate', 'cup']):
        return "food-packaging-boxes", "Food Packaging Boxes"
    if any(k in slug_lower for k in ['jewelry', 'jewellery', 'bracelet', 'pendant', 'ring', 'necklace', 'earring']):
        return "jewelry-packaging", "Jewelry Packaging"
    if any(k in slug_lower for k in ['bag', 'pouch', 'tote', 'carrier', 'foil']):
        return "printed-paper-bags", "Printed Paper Bags"
    if any(k in slug_lower for k in ['rigid', 'luxury', 'magnetic', 'drawer', 'slide']):
        return "printed-rigid-boxes", "Printed Rigid Boxes"
    if any(k in slug_lower for k in ['apparel', 'clothing', 'shirt', 'garment', 'shoe']):
        return "apparel-packaging", "Apparel Packaging"
    if any(k in slug_lower for k in ['cosmetic', 'perfume', 'lipstick', 'soap', 'lotion']):
        return "cosmetic-boxes", "Cosmetic Boxes"
    if any(k in slug_lower for k in ['ecommerce', 'shipping', 'bubble', 'mail', 'corrugated']):
        return "ecommerce-packaging-boxes", "Ecommerce Packaging Boxes"
    return "retails-boxes", "Retail Boxes"

def fetch_and_seed_products():
    url = "https://packagingmindz.com/product-sitemap.xml"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            xml_data = response.read()
    except Exception as e:
        print(f"Could not fetch sitemap directly ({e}), will use fallback products list.")
        seed_fallback_products()
        return

    root = ET.fromstring(xml_data)
    ns = {
        'sm': 'http://www.sitemaps.org/schemas/sitemap/0.9',
        'image': 'http://www.google.com/schemas/sitemap-image/1.1'
    }

    products = []
    for url_tag in root.findall('sm:url', ns):
        loc = url_tag.find('sm:loc', ns)
        if loc is None or not loc.text:
            continue
        product_url = loc.text.strip()
        slug_match = re.search(r'/product/([^/]+)/?', product_url)
        if not slug_match:
            continue
        slug = slug_match.group(1)

        img_loc = None
        img_tag = url_tag.find('image:image/image:loc', ns)
        if img_tag is not None and img_tag.text:
            img_loc = img_tag.text.strip()
        
        name = slug_to_title(slug)
        cat_slug, cat_name = guess_category(slug)
        
        products.append({
            "name": name,
            "slug": slug,
            "cat_slug": cat_slug,
            "cat_name": cat_name,
            "image": img_loc or "https://packagingmindz.com/wp-content/uploads/2026/08/packaging-mindz-1-1-1-1024x427.png"
        })

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    count = 0
    for p in products:
        desc = f"Custom {p['name']} manufactured to order for your brand. Built to your custom dimensions, materials, and premium finishes including spot UV, foil stamping, matte, or gloss."
        specs = "Material: Cardboard / Rigid / Kraft / Corrugated\nPrint: CMYK & Pantone Full Color\nFinish: Matte / Gloss / Spot UV / Hot Foil\nMOQ: 100 units\nTurnaround: 3-7 Business Days (Rush Available)\nShipping: Free Shipping Worldwide"
        cursor.execute('''
        INSERT OR REPLACE INTO products (name, slug, category_slug, category_name, thumbnail, image, description, specifications)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (p["name"], p["slug"], p["cat_slug"], p["cat_name"], p["image"], p["image"], desc, specs))
        count += 1

    conn.commit()
    conn.close()
    print(f"Seeded {count} products from sitemap.")

def seed_fallback_products():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    sample_products = [
        ("Box Sleeve Packaging", "box-sleeve-packaging-to-enhance-your-branding", "retails-boxes", "Retail Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/Box-Sleeve-300x300.png"),
        ("Custom Bakery Boxes", "custom-bakery-boxes", "food-packaging-boxes", "Food Packaging Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/Bakery-Box-300x300.webp"),
        ("Bubble Wrap Rolls", "bubble-wrap-rolls", "ecommerce-packaging-boxes", "Ecommerce Packaging Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/Bubble-Wrap-300x300.webp"),
        ("Custom Candle Boxes", "custom-candle-boxes-that-work-as-hard-as-your-product-does", "retails-boxes", "Retail Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/Candle-Boxes-300x300.webp"),
        ("Custom Cardboard Boxes", "custom-cardboard-boxes-built-to-protect-your-product-and-represent-your-brand", "retails-boxes", "Retail Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/Cardboard-Boxes-300x300.webp"),
        ("Custom Chocolate Boxes", "custom-chocolate-boxes-with-logo-inserts-wholesale-pricing", "food-packaging-boxes", "Food Packaging Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/chocolate-300x300.webp"),
        ("Custom Circle Boxes", "custom-circle-boxes-round-packaging-that-puts-your-product-in-a-different-category", "retails-boxes", "Retail Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/Circle-Boxes-300x300.webp"),
        ("Custom Clothing Boxes", "custom-clothing-boxes", "apparel-packaging", "Apparel Packaging", "https://packagingmindz.com/wp-content/uploads/2026/08/Clothing-Boxes-300x300.webp"),
        ("Custom Bottle Bags", "custom-bottle-bags", "printed-paper-bags", "Printed Paper Bags", "https://packagingmindz.com/wp-content/uploads/2026/08/Bottle-Bags-300x300.webp"),
        ("Custom Bracelet Box Packaging", "custom-bracelet-box-packaging", "jewelry-packaging", "Jewelry Packaging", "https://packagingmindz.com/wp-content/uploads/2026/08/Bracelet-Box-Packaging-300x300.webp"),
        ("Custom Cake Boxes", "custom-cake-boxes", "food-packaging-boxes", "Food Packaging Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/Cake-Boxes-1-300x300.webp"),
        ("Custom Burger Boxes", "custom-burger-boxes", "food-packaging-boxes", "Food Packaging Boxes", "https://packagingmindz.com/wp-content/uploads/2026/08/Burger-Boxes-300x300.webp")
    ]
    for name, slug, cat_slug, cat_name, img in sample_products:
        desc = f"Custom {name} manufactured to order for your brand. Built to your custom dimensions, materials, and premium finishes."
        specs = "Material: Cardboard / Rigid / Kraft / Corrugated\nPrint: CMYK & Pantone\nFinish: Matte / Gloss / Spot UV / Foil\nMOQ: 100 units\nTurnaround: 3-7 Business Days\nShipping: Free Shipping Worldwide"
        cursor.execute('''
        INSERT OR REPLACE INTO products (name, slug, category_slug, category_name, thumbnail, image, description, specifications)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (name, slug, cat_slug, cat_name, img, img, desc, specs))
    conn.commit()
    conn.close()
    print("Seeded fallback products.")

if __name__ == "__main__":
    init_db()
    fetch_and_seed_products()
